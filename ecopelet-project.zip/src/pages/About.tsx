import { Layout } from "@/components/layout/Layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Leaf, Award, Users, Target, Heart, Zap, ArrowRight } from "lucide-react";

const stats = [
  { value: "5+", label: "İllik Təcrübə" },
  { value: "1000+", label: "Razı Müştəri" },
  { value: "5000+", label: "Ton Pelet Satışı" },
  { value: "99%", label: "Müştəri Məmnuniyyəti" },
];

const values = [
  {
    icon: Leaf,
    title: "Ekoloji Yanaşma",
    description: "Təbiətə hörmət, davamlı istehsal metodları",
  },
  {
    icon: Award,
    title: "Keyfiyyət Zəmanəti",
    description: "Beynəlxalq standartlara uyğun istehsal",
  },
  {
    icon: Users,
    title: "Müştəri Mərkəzlilik",
    description: "Müştəri ehtiyaclarına fərdi yanaşma",
  },
  {
    icon: Heart,
    title: "Etibarlılıq",
    description: "Verdiyimiz sözün arxasında dururuq",
  },
];

const team = [
  {
    name: "Əli Məmmədov",
    role: "Direktor",
    description: "15 illik enerji sektorunda təcrübə",
  },
  {
    name: "Leyla Əliyeva",
    role: "Satış Meneceri",
    description: "Müştəri münasibətləri mütəxəssisi",
  },
  {
    name: "Rəşad Hüseynov",
    role: "İstehsal Müdiri",
    description: "Keyfiyyət nəzarəti eksperti",
  },
];

export default function About() {
  return (
    <Layout>
      {/* Hero */}
      <section className="bg-gradient-to-br from-eco-light to-background py-16 lg:py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl lg:text-5xl font-bold text-foreground mb-4">
              Haqqımızda
            </h1>
            <p className="text-lg text-muted-foreground">
              Azərbaycanın aparıcı pelet istehsalçısı və təchizatçısı
            </p>
          </div>
        </div>
      </section>

      {/* Story */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="animate-fade-in">
              <h2 className="text-3xl font-bold text-foreground mb-6">
                Bizim <span className="text-primary">Hekayəmiz</span>
              </h2>
              <div className="space-y-4 text-muted-foreground">
                <p>
                  EcoPelet 2019-cu ildə Azərbaycanda ekoloji təmiz və qənaətcil istilik həlləri
                  təqdim etmək məqsədilə yaradılmışdır. İlk gündən missiyamız yerli bazarda
                  yüksək keyfiyyətli pelet yanacağını əlçatan etmək olmuşdur.
                </p>
                <p>
                  Bu gün biz minlərlə ev sahibi, istixana, emalatxana və kommersiya müəssisəsinə
                  xidmət göstəririk. Premium keyfiyyətli peletlərimiz EN Plus A1 sertifikatına
                  malikdir və beynəlxalq standartlara cavab verir.
                </p>
                <p>
                  Gələcək hədəfimiz Azərbaycanda bərpa olunan enerji mənbələrinin istifadəsini
                  genişləndirmək və daha çox insana ekoloji təmiz istilik həlləri təqdim etməkdir.
                </p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4 animate-fade-in" style={{ animationDelay: "0.2s" }}>
              {stats.map((stat) => (
                <Card key={stat.label} className="text-center">
                  <CardContent className="p-6">
                    <p className="text-4xl font-bold text-primary mb-2">{stat.value}</p>
                    <p className="text-sm text-muted-foreground">{stat.label}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-16 bg-eco-light">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-foreground mb-12">
            Dəyərlərimiz
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((value, index) => (
              <Card
                key={value.title}
                className="text-center animate-fade-in"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <CardContent className="p-6">
                  <div className="w-14 h-14 bg-primary/10 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <value.icon className="w-7 h-7 text-primary" />
                  </div>
                  <h3 className="font-semibold text-foreground mb-2">{value.title}</h3>
                  <p className="text-sm text-muted-foreground">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <Card className="animate-fade-in">
              <CardContent className="p-8">
                <div className="w-14 h-14 bg-primary/10 rounded-xl flex items-center justify-center mb-4">
                  <Target className="w-7 h-7 text-primary" />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-3">Missiyamız</h3>
                <p className="text-muted-foreground">
                  Azərbaycanda hər evə və müəssisəyə ekoloji təmiz, keyfiyyətli və qənaətcil
                  istilik həlləri təqdim etmək, ənənəvi yanacaqlardan alternativ enerji
                  mənbələrinə keçidi asanlaşdırmaq.
                </p>
              </CardContent>
            </Card>
            <Card className="animate-fade-in" style={{ animationDelay: "0.1s" }}>
              <CardContent className="p-8">
                <div className="w-14 h-14 bg-accent/10 rounded-xl flex items-center justify-center mb-4">
                  <Zap className="w-7 h-7 text-accent" />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-3">Vizyonumuz</h3>
                <p className="text-muted-foreground">
                  Qafqaz regionunda pellet yanacağı bazarının lideri olmaq, davamlı enerji
                  həlləri sahəsində innovativ yanaşmalar tətbiq etmək və ətraf mühitin
                  qorunmasına töhfə vermək.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-16 bg-eco-light">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-foreground mb-12">
            Komandamız
          </h2>
          <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {team.map((member, index) => (
              <Card
                key={member.name}
                className="text-center animate-fade-in"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <CardContent className="p-6">
                  <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Users className="w-10 h-10 text-primary" />
                  </div>
                  <h3 className="font-semibold text-foreground">{member.name}</h3>
                  <p className="text-primary text-sm mb-2">{member.role}</p>
                  <p className="text-sm text-muted-foreground">{member.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-primary">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-primary-foreground mb-4">
            Bizimlə İşləmək İstəyirsiniz?
          </h2>
          <p className="text-primary-foreground/90 mb-8 max-w-2xl mx-auto">
            İster fərdi müştəri, istərsə də biznes tərəfdaşı olaraq bizimlə əlaqə saxlayın
          </p>
          <Button size="lg" className="bg-background text-primary hover:bg-background/90" asChild>
            <a href="/contact">
              Əlaqə Saxlayın
              <ArrowRight className="w-5 h-5 ml-2" />
            </a>
          </Button>
        </div>
      </section>
    </Layout>
  );
}
