import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Flame, Leaf, Award, Package, ArrowRight } from "lucide-react";

const products = [
  {
    name: "Premium Pelet",
    subtitle: "EN Plus A1",
    description: "Ən yüksək keyfiyyətli pelet. Fərdi evlər və premium istilik sistemləri üçün ideal.",
    specs: [
      { label: "İstilik dəyəri", value: "4.8+ kCal/kg" },
      { label: "Kül tərkibi", value: "< 0.5%" },
      { label: "Rütubət", value: "< 8%" },
      { label: "Diametr", value: "6mm" },
    ],
    badge: "Ən çox satılan",
    featured: true,
  },
  {
    name: "Standart Pelet",
    subtitle: "EN Plus A2",
    description: "Keyfiyyətli və qənaətcil həll. İstixanalar və sənaye üçün uyğun.",
    specs: [
      { label: "İstilik dəyəri", value: "4.5+ kCal/kg" },
      { label: "Kül tərkibi", value: "< 1%" },
      { label: "Rütubət", value: "< 10%" },
      { label: "Diametr", value: "6mm" },
    ],
    badge: null,
    featured: false,
  },
  {
    name: "Sənaye Peleti",
    subtitle: "Industrial Grade",
    description: "Böyük həcmli sənaye sobaları və istilik sistemləri üçün.",
    specs: [
      { label: "İstilik dəyəri", value: "4.3+ kCal/kg" },
      { label: "Kül tərkibi", value: "< 1.5%" },
      { label: "Rütubət", value: "< 10%" },
      { label: "Diametr", value: "8mm" },
    ],
    badge: "Topdan satış",
    featured: false,
  },
];

const features = [
  {
    icon: Flame,
    title: "Yüksək İstilik Effektivliyi",
    description: "Peletlərimiz maksimum istilik enerjisi verir, yanacaq xərclərini minimuma endirir.",
  },
  {
    icon: Leaf,
    title: "100% Təbii Material",
    description: "Yalnız təmiz odun talaşlarından hazırlanır, heç bir kimyəvi əlavə yoxdur.",
  },
  {
    icon: Award,
    title: "Beynəlxalq Sertifikat",
    description: "EN Plus standartına uyğun istehsal, keyfiyyət zəmanəti.",
  },
  {
    icon: Package,
    title: "Müxtəlif Qablaşdırma",
    description: "15kg, 500kg və 1000kg bigbag qablaşdırma seçimləri.",
  },
];

export default function Products() {
  return (
    <Layout>
      {/* Hero */}
      <section className="bg-gradient-to-br from-eco-light to-background py-16 lg:py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl lg:text-5xl font-bold text-foreground mb-4">
              Məhsullarımız
            </h1>
            <p className="text-lg text-muted-foreground">
              Hər ehtiyaca uyğun keyfiyyətli pelet seçimləri
            </p>
          </div>
        </div>
      </section>

      {/* Products Grid */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-3 gap-6">
            {products.map((product, index) => (
              <Card
                key={product.name}
                className={`relative hover:shadow-xl transition-all duration-300 animate-fade-in ${
                  product.featured ? "border-primary border-2" : ""
                }`}
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                {product.badge && (
                  <Badge className="absolute -top-3 left-4 bg-accent text-accent-foreground">
                    {product.badge}
                  </Badge>
                )}
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>{product.name}</span>
                  </CardTitle>
                  <p className="text-primary font-medium">{product.subtitle}</p>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-muted-foreground">{product.description}</p>
                  
                  <div className="space-y-2 pt-4 border-t border-border">
                    {product.specs.map((spec) => (
                      <div key={spec.label} className="flex justify-between text-sm">
                        <span className="text-muted-foreground">{spec.label}</span>
                        <span className="font-medium text-foreground">{spec.value}</span>
                      </div>
                    ))}
                  </div>

                  <Button className="w-full mt-4" asChild>
                    <a href="https://wa.me/994708734484" target="_blank" rel="noopener noreferrer">
                      Qiymət Soruşun
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </a>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 bg-eco-light">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-foreground mb-12">
            Peletlərimizin Üstünlükləri
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <Card
                key={feature.title}
                className="text-center animate-fade-in"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <CardContent className="p-6">
                  <div className="w-14 h-14 bg-primary/10 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <feature.icon className="w-7 h-7 text-primary" />
                  </div>
                  <h3 className="font-semibold text-foreground mb-2">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
}
