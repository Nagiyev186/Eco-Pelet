import { Layout } from "@/components/layout/Layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Truck, Clock, MapPin, Package, CheckCircle, Phone } from "lucide-react";

const deliveryZones = [
  {
    zone: "Bakı şəhəri",
    condition: "1 tondan yuxarı sifarişlər",
    price: "Pulsuz",
    time: "1-2 iş günü",
  },
  {
    zone: "Abşeron yarımadası",
    condition: "1 tondan yuxarı sifarişlər",
    price: "Pulsuz",
    time: "1-2 iş günü",
  },
  {
    zone: "Sumqayıt, Xırdalan",
    condition: "1 tondan yuxarı sifarişlər",
    price: "Pulsuz",
    time: "1-2 iş günü",
  },
  {
    zone: "Digər rayonlar",
    condition: "Razılaşma ilə",
    price: "Razılaşma ilə",
    time: "2-5 iş günü",
  },
];

const deliverySteps = [
  {
    step: 1,
    title: "Sifariş verin",
    description: "WhatsApp və ya telefon vasitəsilə sifarişinizi bildirin",
  },
  {
    step: 2,
    title: "Təsdiq alın",
    description: "Sifarişiniz təsdiq edilir və çatdırılma tarixi razılaşdırılır",
  },
  {
    step: 3,
    title: "Çatdırılma",
    description: "Sifarişiniz təyin edilmiş tarixdə ünvanınıza çatdırılır",
  },
  {
    step: 4,
    title: "Ödəniş",
    description: "Çatdırılma zamanı nağd və ya köçürmə ilə ödəniş",
  },
];

const features = [
  {
    icon: Truck,
    title: "Özəl Nəqliyyat",
    description: "Öz yük maşınlarımız ilə sürətli çatdırılma",
  },
  {
    icon: Clock,
    title: "Vaxtında Çatdırılma",
    description: "Razılaşdırılmış tarixdə çatdırılma zəmanəti",
  },
  {
    icon: Package,
    title: "Boşaltma Xidməti",
    description: "İstəyə uyğun boşaltma xidməti (əlavə ödənişli)",
  },
  {
    icon: MapPin,
    title: "Bütün Azərbaycana",
    description: "Ölkənin hər yerinə çatdırılma imkanı",
  },
];

export default function Delivery() {
  return (
    <Layout>
      {/* Hero */}
      <section className="bg-gradient-to-br from-eco-light to-background py-16 lg:py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl lg:text-5xl font-bold text-foreground mb-4">
              Çatdırılma Xidməti
            </h1>
            <p className="text-lg text-muted-foreground">
              Bakı və ətraf rayonlara sürətli və etibarlı çatdırılma
            </p>
          </div>
        </div>
      </section>

      {/* Delivery Zones */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-foreground mb-12">
            Çatdırılma Zonaları
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {deliveryZones.map((zone, index) => (
              <Card
                key={zone.zone}
                className="hover:shadow-lg transition-all animate-fade-in"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-4">
                    <MapPin className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-semibold text-lg text-foreground mb-3">{zone.zone}</h3>
                  <div className="space-y-2 text-sm">
                    <p className="text-muted-foreground">{zone.condition}</p>
                    <p className="text-primary font-medium">{zone.price}</p>
                    <p className="text-muted-foreground flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {zone.time}
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="py-16 bg-eco-light">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-foreground mb-12">
            Sifariş Prosesi
          </h2>
          <div className="grid md:grid-cols-4 gap-6 max-w-5xl mx-auto">
            {deliverySteps.map((step, index) => (
              <div
                key={step.step}
                className="text-center animate-fade-in"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="w-14 h-14 bg-primary text-primary-foreground rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                  {step.step}
                </div>
                <h3 className="font-semibold text-foreground mb-2">{step.title}</h3>
                <p className="text-sm text-muted-foreground">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <Card
                key={feature.title}
                className="text-center animate-fade-in"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <CardContent className="p-6">
                  <div className="w-14 h-14 bg-primary/10 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <feature.icon className="w-7 h-7 text-primary" />
                  </div>
                  <h3 className="font-semibold text-foreground mb-2">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-primary">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-primary-foreground mb-4">
            Çatdırılma Haqqında Sualınız Var?
          </h2>
          <p className="text-primary-foreground/90 mb-8 max-w-2xl mx-auto">
            Xüsusi tələbləriniz varsa, bizimlə əlaqə saxlayın. Sizin üçün uyğun həll tapacağıq.
          </p>
          <Button size="lg" className="bg-background text-primary hover:bg-background/90" asChild>
            <a href="tel:+994708734484">
              <Phone className="w-5 h-5 mr-2" />
              +994 70 873 44 84
            </a>
          </Button>
        </div>
      </section>
    </Layout>
  );
}
