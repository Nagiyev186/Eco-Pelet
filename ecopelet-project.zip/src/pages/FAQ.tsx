import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { MessageCircle, Phone } from "lucide-react";

const faqs = [
  {
    question: "Pelet nədir və nə üçün istifadə olunur?",
    answer:
      "Pelet təbii odun talaşlarından presləmə üsulu ilə hazırlanan kiçik silindrşəkilli yanacaqdır. Əsasən istilik sistemlərində, sobalar və qazanlarda yanacaq kimi istifadə olunur. Yüksək istilik dəyəri və aşağı kül tərkibi ilə ənənəvi yanacaqlardan daha effektivdir.",
  },
  {
    question: "Peletin digər yanacaqlardan üstünlüyü nədir?",
    answer:
      "Pelet qaz və mazutla müqayisədə 30-40% daha qənaətcildir. Ekoloji təmizdir, CO2 emissiyası minimumdur. Saxlanması asandır və uzunmüddətli saxlama zamanı keyfiyyətini itirmir. Avtomatik istilik sistemlərində istifadəyə yararlıdır.",
  },
  {
    question: "Hansı istilik sistemlərində istifadə edə bilərəm?",
    answer:
      "Pelet xüsusi pelet sobaları, pelet qazanları və avtomatik qidalandırmalı istilik sistemlərində istifadə olunur. Həmçinin bəzi universal sobalarda da istifadə edilə bilər. Sisteminizə uyğunluq üçün bizimlə məsləhətləşə bilərsiniz.",
  },
  {
    question: "Minimum sifariş miqdarı nə qədərdir?",
    answer:
      "Kisə sifarişlərində minimum 10 kisə (150kg), topdan sifarişlərdə minimum 1 ton. 5 tondan yuxarı sifarişlərdə xüsusi endirimli qiymətlər tətbiq olunur.",
  },
  {
    question: "Çatdırılma necə həyata keçirilir?",
    answer:
      "Bakı şəhəri və Abşeron yarımadasına 1 tondan yuxarı sifarişlərdə çatdırılma pulsuzdur. Digər rayonlara çatdırılma məsafəyə görə razılaşdırılır. Çatdırılma adətən 1-2 iş günü ərzində həyata keçirilir.",
  },
  {
    question: "Ödəniş necə həyata keçirilir?",
    answer:
      "Ödəniş çatdırılma zamanı nağd və ya bank köçürməsi ilə həyata keçirilə bilər. Topdan sifarişlərdə ilkin ödəniş tələb oluna bilər. Korporativ müştərilər üçün müqavilə əsasında ödəniş şərtləri razılaşdırılır.",
  },
  {
    question: "Peleti necə saxlamalıyam?",
    answer:
      "Pelet quru və havalanan yerdə saxlanmalıdır. Rütubətdən qorunmalıdır, çünki rütubət peletin keyfiyyətinə təsir edir. Orijinal qablaşdırmada və ya konteynerlərdə saxlamaq tövsiyə olunur.",
  },
  {
    question: "Peletin keyfiyyətini necə yoxlaya bilərəm?",
    answer:
      "Keyfiyyətli pelet bərk, hamar səthli və parlaq olmalıdır. Əl ilə sıxdıqda ovulmamalıdır. Rəngi açıq sarıdan açıq qəhvəyiyə qədər dəyişə bilər. Bizim peletlərimiz EN Plus A1 sertifikatlıdır.",
  },
  {
    question: "Topdan satış üçün endirimlər varmı?",
    answer:
      "Bəli, 5 tondan yuxarı sifarişlərdə xüsusi qiymətlər tətbiq olunur. Müntəzəm müştərilər və uzunmüddətli müqavilələr üçün əlavə endirimlər mövcuddur. Dəqiq qiymət təklifi üçün bizimlə əlaqə saxlayın.",
  },
  {
    question: "Geri qaytarma şərtləri nədir?",
    answer:
      "Çatdırılma zamanı pelletin keyfiyyətini yoxlayın. Əgər keyfiyyət problemi aşkar etsəniz, 24 saat ərzində bizə bildirin. Keyfiyyət şikayətləri araşdırılır və haqlı hallarda məhsul dəyişdirilir.",
  },
];

export default function FAQ() {
  return (
    <Layout>
      {/* Hero */}
      <section className="bg-gradient-to-br from-eco-light to-background py-16 lg:py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl lg:text-5xl font-bold text-foreground mb-4">
              Tez-tez Verilən Suallar
            </h1>
            <p className="text-lg text-muted-foreground">
              Pelet haqqında ən çox soruşulan sualların cavabları
            </p>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <Accordion type="single" collapsible className="space-y-4">
              {faqs.map((faq, index) => (
                <AccordionItem
                  key={index}
                  value={`item-${index}`}
                  className="bg-card border border-border rounded-lg px-6 animate-fade-in"
                  style={{ animationDelay: `${index * 0.05}s` }}
                >
                  <AccordionTrigger className="text-left font-medium text-foreground hover:text-primary">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </div>
      </section>

      {/* Still have questions */}
      <section className="py-16 bg-eco-light">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-foreground mb-4">
              Başqa Sualınız Var?
            </h2>
            <p className="text-muted-foreground mb-8">
              Cavab tapa bilmədiyiniz suallarınız üçün bizimlə əlaqə saxlayın.
              Mütəxəssislərimiz sizə kömək etməkdən məmnun olacaq.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" asChild>
                <a href="https://wa.me/994708734484" target="_blank" rel="noopener noreferrer">
                  <MessageCircle className="w-5 h-5 mr-2" />
                  WhatsApp ilə Yazın
                </a>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <a href="tel:+994708734484">
                  <Phone className="w-5 h-5 mr-2" />
                  Zəng Edin
                </a>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}
