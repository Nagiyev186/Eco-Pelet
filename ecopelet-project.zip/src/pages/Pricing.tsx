import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, ArrowRight, Truck, Package } from "lucide-react";

const pricingPlans = [
  {
    name: "Fərdi Sifariş",
    quantity: "15kg kisələr",
    price: "8",
    unit: "AZN/kisə",
    description: "Kiçik həcmli ehtiyaclar üçün",
    features: [
      "Minimum 10 kisə",
      "Asan daşıma və saxlama",
      "Premium keyfiyyət",
      "Bakıya pulsuz çatdırılma (50 kisədən yuxarı)",
    ],
    popular: false,
  },
  {
    name: "Standart Paket",
    quantity: "1 ton",
    price: "450",
    unit: "AZN/ton",
    description: "Evlər və kiçik müəssisələr üçün",
    features: [
      "1 ton minimum",
      "Bakıya pulsuz çatdırılma",
      "15kg kisələrdə qablaşdırma",
      "Keyfiyyət sertifikatı",
      "Texniki dəstək",
    ],
    popular: true,
  },
  {
    name: "Topdan Satış",
    quantity: "5+ ton",
    price: "400",
    unit: "AZN/ton",
    description: "Böyük həcmli sifarişlər üçün",
    features: [
      "5 tondan başlayan sifarişlər",
      "Azərbaycana pulsuz çatdırılma",
      "Bigbag və ya kisə seçimi",
      "Xüsusi qiymət təklifi",
      "Müqavilə əsasında",
      "Prioritet çatdırılma",
    ],
    popular: false,
  },
];

const additionalInfo = [
  {
    icon: Truck,
    title: "Çatdırılma",
    items: [
      "Bakı şəhəri: 1 tondan yuxarı pulsuz",
      "Abşeron: 1 tondan yuxarı pulsuz",
      "Digər rayonlar: Razılaşma ilə",
    ],
  },
  {
    icon: Package,
    title: "Qablaşdırma Seçimləri",
    items: [
      "15kg polietilen kisələr",
      "500kg bigbag",
      "1000kg bigbag",
    ],
  },
];

export default function Pricing() {
  return (
    <Layout>
      {/* Hero */}
      <section className="bg-gradient-to-br from-eco-light to-background py-16 lg:py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl lg:text-5xl font-bold text-foreground mb-4">
              Qiymətlər
            </h1>
            <p className="text-lg text-muted-foreground">
              Şəffaf qiymətlər, gizli xərclər yoxdur
            </p>
          </div>
        </div>
      </section>

      {/* Pricing Cards */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {pricingPlans.map((plan, index) => (
              <Card
                key={plan.name}
                className={`relative hover:shadow-xl transition-all duration-300 animate-fade-in ${
                  plan.popular ? "border-primary border-2 scale-105" : ""
                }`}
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                {plan.popular && (
                  <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary">
                    Ən populyar
                  </Badge>
                )}
                <CardHeader className="text-center pb-2">
                  <CardTitle className="text-xl">{plan.name}</CardTitle>
                  <p className="text-muted-foreground text-sm">{plan.quantity}</p>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="text-center">
                    <span className="text-4xl font-bold text-foreground">{plan.price}</span>
                    <span className="text-muted-foreground ml-2">{plan.unit}</span>
                    <p className="text-sm text-muted-foreground mt-1">{plan.description}</p>
                  </div>

                  <ul className="space-y-3">
                    {plan.features.map((feature) => (
                      <li key={feature} className="flex items-start gap-2 text-sm">
                        <Check className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                        <span className="text-foreground">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <Button
                    className={`w-full ${plan.popular ? "bg-primary" : ""}`}
                    variant={plan.popular ? "default" : "outline"}
                    asChild
                  >
                    <a href="https://wa.me/994708734484" target="_blank" rel="noopener noreferrer">
                      Sifariş Ver
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </a>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Additional Info */}
      <section className="py-16 bg-eco-light">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {additionalInfo.map((info) => (
              <Card key={info.title} className="animate-fade-in">
                <CardContent className="p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                      <info.icon className="w-5 h-5 text-primary" />
                    </div>
                    <h3 className="font-semibold text-lg text-foreground">{info.title}</h3>
                  </div>
                  <ul className="space-y-2">
                    {info.items.map((item) => (
                      <li key={item} className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Check className="w-4 h-4 text-primary" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center mt-12">
            <p className="text-muted-foreground mb-4">
              Xüsusi qiymət təklifi almaq üçün bizimlə əlaqə saxlayın
            </p>
            <Button size="lg" asChild>
              <a href="tel:+994708734484">
                Zəng Edin: +994 70 873 44 84
              </a>
            </Button>
          </div>
        </div>
      </section>
    </Layout>
  );
}
