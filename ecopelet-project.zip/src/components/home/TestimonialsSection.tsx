import { Star, Quote } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const testimonials = [
  {
    name: "Elçin Məmmədov",
    role: "Ev sahibi, Bakı",
    content: "EcoPelet istifadə etdiyimdən bəri qaz xərclərimi 40% azaltdım. Keyfiyyət əladır, heç bir problem yaşamadım.",
    rating: 5,
  },
  {
    name: "Səbinə Əliyeva",
    role: "İstixana sahibi, Şəmkir",
    content: "İstixanamızı peletlə qızdırırıq, həm qənaətcil, həm də bitkilər üçün daha təmiz mühit yaradır.",
    rating: 5,
  },
  {
    name: "Rəşad Hüseynov",
    role: "Emalatxana müdiri, Sumqayıt",
    content: "Sənaye sobalarımız üçün ideal yanacaq. Stabil istilik verir və kül problemi yoxdur.",
    rating: 5,
  },
];

export function TestimonialsSection() {
  return (
    <section className="py-16 lg:py-24 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
            Müştərilərimiz <span className="text-primary">Nə Deyir?</span>
          </h2>
          <p className="text-muted-foreground">
            Yüzlərlə razı müştərimizin rəyləri
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <Card
              key={testimonial.name}
              className="hover:shadow-lg transition-all duration-300 animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <CardContent className="p-6">
                <Quote className="w-8 h-8 text-primary/30 mb-4" />
                <p className="text-foreground mb-4">{testimonial.content}</p>
                <div className="flex items-center gap-1 mb-4">
                  {Array.from({ length: testimonial.rating }).map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-accent text-accent" />
                  ))}
                </div>
                <div>
                  <p className="font-semibold text-foreground">{testimonial.name}</p>
                  <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
