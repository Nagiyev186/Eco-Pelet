import { Button } from "@/components/ui/button";
import { Phone, MessageCircle, ArrowRight } from "lucide-react";

export function CTASection() {
  return (
    <section className="py-16 lg:py-24 bg-gradient-to-br from-primary to-primary/80">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center text-primary-foreground">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">
            İndi Sifariş Verin, Pulsuz Çatdırılma Əldə Edin!
          </h2>
          <p className="text-xl opacity-90 mb-8">
            Bakı və ətraf rayonlara minimum 1 ton sifarişlərdə pulsuz çatdırılma
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              className="bg-background text-primary hover:bg-background/90 text-lg px-8"
              asChild
            >
              <a href="https://wa.me/994708734484" target="_blank" rel="noopener noreferrer">
                <MessageCircle className="w-5 h-5 mr-2" />
                WhatsApp ilə Sifariş
                <ArrowRight className="w-5 h-5 ml-2" />
              </a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground/10 text-lg px-8"
              asChild
            >
              <a href="tel:+994708734484">
                <Phone className="w-5 h-5 mr-2" />
                +994 70 873 44 84
              </a>
            </Button>
          </div>

          <div className="mt-8 flex flex-wrap justify-center gap-8 text-sm opacity-80">
            <span>✓ Sürətli çatdırılma</span>
            <span>✓ Keyfiyyət zəmanəti</span>
            <span>✓ Əlverişli qiymətlər</span>
          </div>
        </div>
      </div>
    </section>
  );
}
