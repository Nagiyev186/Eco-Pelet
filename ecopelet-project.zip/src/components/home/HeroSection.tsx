import { Button } from "@/components/ui/button";
import { Phone, ArrowRight, Flame, Leaf, Shield } from "lucide-react";

export function HeroSection() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-eco-light via-background to-wood-light">
      <div className="container mx-auto px-4 py-16 lg:py-24">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8 animate-fade-in">
            <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium">
              <Leaf className="w-4 h-4" />
              Ekoloji Təmiz Yanacaq
            </div>
            
            <h1 className="text-4xl lg:text-6xl font-bold text-foreground leading-tight text-balance">
              Keyfiyyətli <span className="text-primary">Odun Peletləri</span> ilə Qənaətcil İstilik
            </h1>
            
            <p className="text-lg text-muted-foreground max-w-xl">
              Yüksək istilik dəyəri, aşağı kül tərkibi və ekoloji təmizliyi ilə evlər, 
              istixanalar və sənaye obyektləri üçün ideal yanacaq həlli.
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="bg-primary hover:bg-primary/90 text-lg px-8" asChild>
                <a href="https://wa.me/994708734484" target="_blank" rel="noopener noreferrer">
                  WhatsApp ilə Sifariş
                  <ArrowRight className="w-5 h-5 ml-2" />
                </a>
              </Button>
              <Button size="lg" variant="outline" className="text-lg px-8" asChild>
                <a href="tel:+994708734484">
                  <Phone className="w-5 h-5 mr-2" />
                  Zəng Edin
                </a>
              </Button>
            </div>

            <div className="flex flex-wrap gap-6 pt-4">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                  <Flame className="w-4 h-4 text-primary" />
                </div>
                Yüksək istilik dəyəri
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                  <Leaf className="w-4 h-4 text-primary" />
                </div>
                Ekoloji təmiz
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                  <Shield className="w-4 h-4 text-primary" />
                </div>
                Keyfiyyət zəmanəti
              </div>
            </div>
          </div>

          <div className="relative animate-fade-in" style={{ animationDelay: "0.2s" }}>
            <div className="relative bg-gradient-to-br from-primary/20 to-wood/20 rounded-3xl p-8 lg:p-12">
              <div className="aspect-square bg-gradient-to-br from-wood-light to-secondary rounded-2xl flex items-center justify-center">
                <div className="text-center space-y-4">
                  <div className="w-32 h-32 mx-auto bg-wood rounded-full flex items-center justify-center">
                    <Flame className="w-16 h-16 text-accent" />
                  </div>
                  <p className="text-2xl font-bold text-foreground">Premium Pelet</p>
                  <p className="text-muted-foreground">EN Plus A1 Sertifikatlı</p>
                </div>
              </div>
              
              {/* Floating stats */}
              <div className="absolute -top-4 -right-4 bg-card shadow-lg rounded-2xl p-4 border border-border">
                <p className="text-3xl font-bold text-primary">4.8+</p>
                <p className="text-xs text-muted-foreground">kCal/kg</p>
              </div>
              
              <div className="absolute -bottom-4 -left-4 bg-card shadow-lg rounded-2xl p-4 border border-border">
                <p className="text-3xl font-bold text-primary">&lt;1%</p>
                <p className="text-xs text-muted-foreground">Kül tərkibi</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
