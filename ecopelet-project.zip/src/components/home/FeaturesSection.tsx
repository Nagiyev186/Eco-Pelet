import { Flame, Leaf, Truck, BadgeCheck, Banknote, Users } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const features = [
  {
    icon: Flame,
    title: "Yüksək İstilik Dəyəri",
    description: "4.8+ kCal/kg istilik dəyəri ilə maksimum səmərəlilik",
  },
  {
    icon: Leaf,
    title: "Ekoloji Təmiz",
    description: "100% təbii odun materialından hazırlanmış, kimyəvi əlavəsiz",
  },
  {
    icon: BadgeCheck,
    title: "Keyfiyyət Sertifikatı",
    description: "EN Plus A1 beynəlxalq standartına uyğun istehsal",
  },
  {
    icon: Banknote,
    title: "Qənaətcil Qiymət",
    description: "Ənənəvi yanacaqlarla müqayisədə 30-40% qənaət",
  },
  {
    icon: Truck,
    title: "Pulsuz Çatdırılma",
    description: "Bakı və ətraf rayonlara pulsuz çatdırılma xidməti",
  },
  {
    icon: Users,
    title: "Peşəkar Dəstək",
    description: "Texniki məsləhət və satış sonrası xidmət",
  },
];

export function FeaturesSection() {
  return (
    <section className="py-16 lg:py-24 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
            Niyə <span className="text-primary">EcoPelet</span> Seçməlisiniz?
          </h2>
          <p className="text-muted-foreground">
            Premium keyfiyyətli peletlərimiz ilə evinizi və işinizi effektiv şəkildə isidə bilərsiniz.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <Card
              key={feature.title}
              className="group hover:shadow-lg transition-all duration-300 border-border hover:border-primary/30 animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                  <feature.icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  {feature.title}
                </h3>
                <p className="text-muted-foreground text-sm">
                  {feature.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
