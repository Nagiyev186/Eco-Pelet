import { Home, Factory, Warehouse, Building2 } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const customers = [
  {
    icon: Home,
    title: "Ev Sahibləri",
    description: "Fərdi evlər və villalar üçün qənaətcil istilik həlli",
    color: "bg-primary/10 text-primary",
  },
  {
    icon: Factory,
    title: "Emalatxanalar",
    description: "Sənaye müəssisələri üçün güclü istilik mənbəyi",
    color: "bg-accent/10 text-accent",
  },
  {
    icon: Warehouse,
    title: "İstixanalar",
    description: "Kənd təsərrüfatı obyektləri üçün stabil istilik",
    color: "bg-wood/10 text-wood",
  },
  {
    icon: Building2,
    title: "Kommersiya Binaları",
    description: "Ofis və mağazalar üçün effektiv isitmə",
    color: "bg-primary/10 text-primary",
  },
];

export function CustomersSection() {
  return (
    <section className="py-16 lg:py-24 bg-eco-light">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
            Kimlər Üçün <span className="text-primary">İdeal</span>?
          </h2>
          <p className="text-muted-foreground">
            Peletlərimiz müxtəlif sahələrdə istifadə oluna bilər
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {customers.map((customer, index) => (
            <Card
              key={customer.title}
              className="text-center hover:shadow-lg transition-all duration-300 border-border hover:border-primary/30 animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <CardContent className="p-6">
                <div className={`w-16 h-16 ${customer.color} rounded-2xl flex items-center justify-center mx-auto mb-4`}>
                  <customer.icon className="w-8 h-8" />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  {customer.title}
                </h3>
                <p className="text-muted-foreground text-sm">
                  {customer.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
