import { Link } from "react-router-dom";
import { Leaf, Phone, Mail, MapPin, Facebook, Instagram } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-foreground text-background">
      <div className="container mx-auto px-4 py-12 lg:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <Link to="/" className="flex items-center gap-2">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <Leaf className="w-6 h-6 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold">EcoPelet</span>
            </Link>
            <p className="text-background/70 text-sm">
              Azərbaycanda keyfiyyətli odun peletləri istehsalçısı. Ekoloji təmiz və iqtisadi istilik həlləri.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-semibold mb-4">Əsas Səhifələr</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/products" className="text-background/70 hover:text-background text-sm transition-colors">
                  Məhsullar
                </Link>
              </li>
              <li>
                <Link to="/pricing" className="text-background/70 hover:text-background text-sm transition-colors">
                  Qiymətlər
                </Link>
              </li>
              <li>
                <Link to="/delivery" className="text-background/70 hover:text-background text-sm transition-colors">
                  Çatdırılma
                </Link>
              </li>
              <li>
                <Link to="/about" className="text-background/70 hover:text-background text-sm transition-colors">
                  Haqqımızda
                </Link>
              </li>
              <li>
                <Link to="/faq" className="text-background/70 hover:text-background text-sm transition-colors">
                  FAQ
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-semibold mb-4">Əlaqə</h3>
            <ul className="space-y-3">
              <li className="flex items-center gap-2 text-sm text-background/70">
                <Phone className="w-4 h-4 text-primary" />
                +994 70 873 44 84
              </li>
              <li className="flex items-center gap-2 text-sm text-background/70">
                <Mail className="w-4 h-4 text-primary" />
                info@ecopellet.az
              </li>
              <li className="flex items-start gap-2 text-sm text-background/70">
                <MapPin className="w-4 h-4 text-primary mt-0.5" />
                Bakı şəhəri, Nəsimi rayonu
              </li>
            </ul>
          </div>

          {/* Social */}
          <div>
            <h3 className="font-semibold mb-4">Sosial Şəbəkələr</h3>
            <div className="flex gap-4">
              <a
                href="#"
                className="w-10 h-10 bg-background/10 rounded-lg flex items-center justify-center hover:bg-primary transition-colors"
              >
                <Facebook className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-background/10 rounded-lg flex items-center justify-center hover:bg-primary transition-colors"
              >
                <Instagram className="w-5 h-5" />
              </a>
            </div>
            <div className="mt-6">
              <p className="text-sm text-background/70">İş saatları:</p>
              <p className="text-sm">Bazar ertəsi - Şənbə: 09:00 - 18:00</p>
            </div>
          </div>
        </div>

        <div className="border-t border-background/20 mt-12 pt-8 text-center text-sm text-background/60">
          <p>© 2026 EcoPelet. Bütün hüquqlar qorunur.</p>
        </div>
      </div>
    </footer>
  );
}
