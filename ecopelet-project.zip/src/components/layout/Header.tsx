import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, X, Phone, Leaf } from "lucide-react";
import { Button } from "@/components/ui/button";

const navigation = [
  { name: "Ana Səhifə", href: "/" },
  { name: "Məhsullar", href: "/products" },
  { name: "Qiymətlər", href: "/pricing" },
  { name: "Çatdırılma", href: "/delivery" },
  { name: "Haqqımızda", href: "/about" },
  { name: "FAQ", href: "/faq" },
  { name: "Əlaqə", href: "/contact" },
];

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();

  return (
    <header className="sticky top-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border">
      <nav className="container mx-auto flex items-center justify-between py-4 px-4 lg:px-8">
        <Link to="/" className="flex items-center gap-2">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <Leaf className="w-6 h-6 text-primary-foreground" />
          </div>
          <span className="text-xl font-bold text-foreground">EcoPelet</span>
        </Link>

        {/* Desktop navigation */}
        <div className="hidden lg:flex lg:gap-8">
          {navigation.map((item) => (
            <Link
              key={item.name}
              to={item.href}
              className={`text-sm font-medium transition-colors hover:text-primary ${
                location.pathname === item.href
                  ? "text-primary"
                  : "text-muted-foreground"
              }`}
            >
              {item.name}
            </Link>
          ))}
        </div>

        <div className="hidden lg:flex lg:items-center lg:gap-4">
          <a href="tel:+994708734484" className="flex items-center gap-2 text-sm font-medium text-foreground">
            <Phone className="w-4 h-4 text-primary" />
            +994 70 873 44 84
          </a>
          <Button asChild className="bg-primary hover:bg-primary/90">
            <a href="https://wa.me/994708734484" target="_blank" rel="noopener noreferrer">
              WhatsApp ilə Sifariş
            </a>
          </Button>
        </div>

        {/* Mobile menu button */}
        <button
          type="button"
          className="lg:hidden p-2"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
          {mobileMenuOpen ? (
            <X className="w-6 h-6 text-foreground" />
          ) : (
            <Menu className="w-6 h-6 text-foreground" />
          )}
        </button>
      </nav>

      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-border bg-background">
          <div className="container mx-auto px-4 py-4 space-y-4">
            {navigation.map((item) => (
              <Link
                key={item.name}
                to={item.href}
                onClick={() => setMobileMenuOpen(false)}
                className={`block text-base font-medium transition-colors hover:text-primary ${
                  location.pathname === item.href
                    ? "text-primary"
                    : "text-muted-foreground"
                }`}
              >
                {item.name}
              </Link>
            ))}
            <div className="pt-4 border-t border-border space-y-3">
              <a
                href="tel:+994708734484"
                className="flex items-center gap-2 text-sm font-medium text-foreground"
              >
                <Phone className="w-4 h-4 text-primary" />
                +994 70 873 44 84
              </a>
              <Button asChild className="w-full bg-primary hover:bg-primary/90">
                <a href="https://wa.me/994708734484" target="_blank" rel="noopener noreferrer">
                  WhatsApp ilə Sifariş
                </a>
              </Button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
